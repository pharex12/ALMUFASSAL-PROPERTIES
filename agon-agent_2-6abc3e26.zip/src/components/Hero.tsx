import React, { useState, useEffect, useRef } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { Search, MapPin, DollarSign, Home, Compass, ShieldCheck, Award, Star } from 'lucide-react';

interface HeroProps {
  onSearch: (filters: { category: string; location: string; minPrice: string; maxPrice: string }) => void;
}

export default function Hero({ onSearch }: HeroProps) {
  const [category, setCategory] = useState('All');
  const [location, setLocation] = useState('All');
  const [minPrice, setMinPrice] = useState('');
  const [maxPrice, setMaxPrice] = useState('');

  // Parallax effects
  const heroRef = useRef<HTMLDivElement>(null);
  const { scrollY } = useScroll();
  const yBg = useTransform(scrollY, [0, 800], [0, 200]);
  const yText = useTransform(scrollY, [0, 800], [0, -100]);
  const opacityText = useTransform(scrollY, [0, 600], [1, 0]);

  // Mouse move effect for 3D depth
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const handleMouseMove = (e: React.MouseEvent) => {
    if (!heroRef.current) return;
    const { clientX, clientY } = e;
    const { innerWidth, innerHeight } = window;
    const x = (clientX - innerWidth / 2) / 30;
    const y = (clientY - innerHeight / 2) / 30;
    setMousePos({ x, y });
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch({ category, location, minPrice, maxPrice });
    const section = document.getElementById('properties');
    if (section) {
      section.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div 
      ref={heroRef}
      onMouseMove={handleMouseMove}
      className="relative min-h-screen bg-[#020714] overflow-hidden flex flex-col justify-center pt-24 pb-16 px-6"
      id="home"
    >
      {/* 3D Background Render Layer with Parallax */}
      <motion.div 
        style={{ y: yBg }}
        className="absolute inset-0 z-0 pointer-events-none"
      >
        <div className="absolute inset-0 bg-gradient-to-b from-[#020714]/20 via-[#030a1c]/80 to-[#020714] z-10"></div>
        <img 
          src="/images/hero-building.png" 
          alt="Luxury Skyline Render" 
          className="w-full h-full object-cover object-center scale-105 transition-transform duration-700 opacity-70"
          style={{
            transform: `translate3d(${mousePos.x * 0.4}px, ${mousePos.y * 0.4}px, 0) scale(1.05)`
          }}
        />
      </motion.div>

      {/* Modern Grid Overlay */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(251,191,36,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(251,191,36,0.02)_1px,transparent_1px)] bg-[size:100px_100px] pointer-events-none z-10"></div>

      {/* Floating Gold Nebula / Glowing Orbs */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full bg-amber-500/10 blur-[120px] pointer-events-none animate-pulse duration-[8000ms] z-10"></div>
      <div className="absolute bottom-1/3 right-1/4 w-80 h-80 rounded-full bg-blue-500/10 blur-[100px] pointer-events-none animate-pulse duration-[6000ms] z-10"></div>

      {/* Content Container */}
      <div className="relative max-w-7xl mx-auto w-full z-20 flex flex-col items-center">
        
        {/* Top Tag */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-amber-400/10 border border-amber-400/20 text-amber-400 text-xs font-semibold tracking-[0.2em] uppercase mb-8 backdrop-blur-md"
        >
          <Award className="w-3.5 h-3.5 animate-spin duration-[10000ms]" />
          <span>The Pinnacle of Architectural Mastery</span>
        </motion.div>

        {/* Headline & Value Prop */}
        <motion.div 
          style={{ y: yText, opacity: opacityText }}
          className="text-center max-w-4xl mb-12"
        >
          <h1 className="text-5xl md:text-7xl font-serif font-extrabold tracking-tight text-white mb-6 leading-tight">
            Curators of <br />
            <span className="bg-gradient-to-r from-amber-200 via-amber-400 to-amber-600 bg-clip-text text-transparent font-serif italic drop-shadow-sm">
              Legendary Estates
            </span>
          </h1>
          <p className="text-lg md:text-xl text-slate-300 font-light tracking-wide max-w-2xl mx-auto leading-relaxed">
            Almufassal Properties crafts exceptional residential legacies. Explore our highly curated collection of ultra-luxury penthouses, waterfront villas, and architectural marvels.
          </p>
        </motion.div>

        {/* Glassmorphic Search Engine */}
        <motion.form 
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          onSubmit={handleSearchSubmit}
          className="w-full max-w-5xl bg-[#030a1c]/60 backdrop-blur-xl border border-white/10 rounded-2xl md:rounded-full p-4 md:p-3 flex flex-col md:flex-row items-center gap-4 shadow-2xl shadow-black/60 hover:border-amber-500/30 transition-all duration-500"
          style={{
            transform: `translate3d(${mousePos.x * -0.2}px, ${mousePos.y * -0.2}px, 0)`
          }}
        >
          {/* Category Filter */}
          <div className="flex items-center gap-3 w-full md:w-auto px-4 py-2 border-b md:border-b-0 md:border-r border-white/10 group">
            <Home className="w-5 h-5 text-amber-400 shrink-0 group-hover:scale-110 transition-transform" />
            <div className="w-full">
              <label className="block text-[10px] text-slate-400 tracking-wider uppercase font-semibold">Estate Type</label>
              <select 
                value={category} 
                onChange={(e) => setCategory(e.target.value)}
                className="bg-transparent text-white text-sm font-medium focus:outline-none w-full cursor-pointer pr-4 appearance-none"
              >
                <option value="All" className="bg-[#030a1c] text-white">All Estates</option>
                <option value="Penthouse" className="bg-[#030a1c] text-white">Penthouses</option>
                <option value="Waterfront Villa" className="bg-[#030a1c] text-white">Waterfront Villas</option>
                <option value="Private Mansion" className="bg-[#030a1c] text-white">Private Mansions</option>
              </select>
            </div>
          </div>

          {/* Location Filter */}
          <div className="flex items-center gap-3 w-full md:w-auto px-4 py-2 border-b md:border-b-0 md:border-r border-white/10 group">
            <MapPin className="w-5 h-5 text-amber-400 shrink-0 group-hover:scale-110 transition-transform" />
            <div className="w-full">
              <label className="block text-[10px] text-slate-400 tracking-wider uppercase font-semibold">Location</label>
              <select 
                value={location} 
                onChange={(e) => setLocation(e.target.value)}
                className="bg-transparent text-white text-sm font-medium focus:outline-none w-full cursor-pointer pr-4 appearance-none"
              >
                <option value="All" className="bg-[#030a1c] text-white">All Locations</option>
                <option value="Palm Jumeirah" className="bg-[#030a1c] text-white">Palm Jumeirah</option>
                <option value="Downtown Dubai" className="bg-[#030a1c] text-white">Downtown Dubai</option>
                <option value="Dubai Marina" className="bg-[#030a1c] text-white">Dubai Marina</option>
                <option value="Emirates Hills" className="bg-[#030a1c] text-white">Emirates Hills</option>
              </select>
            </div>
          </div>

          {/* Price Range Filter */}
          <div className="flex items-center gap-3 w-full md:w-auto px-4 py-2 group flex-1">
            <DollarSign className="w-5 h-5 text-amber-400 shrink-0 group-hover:scale-110 transition-transform" />
            <div className="grid grid-cols-2 gap-2 w-full">
              <div>
                <label className="block text-[10px] text-slate-400 tracking-wider uppercase font-semibold">Min Price ($M)</label>
                <input 
                  type="number" 
                  placeholder="Min" 
                  value={minPrice}
                  onChange={(e) => setMinPrice(e.target.value)}
                  className="bg-transparent text-white text-sm font-medium focus:outline-none w-full placeholder:text-slate-500"
                />
              </div>
              <div>
                <label className="block text-[10px] text-slate-400 tracking-wider uppercase font-semibold">Max Price ($M)</label>
                <input 
                  type="number" 
                  placeholder="Max" 
                  value={maxPrice}
                  onChange={(e) => setMaxPrice(e.target.value)}
                  className="bg-transparent text-white text-sm font-medium focus:outline-none w-full placeholder:text-slate-500"
                />
              </div>
            </div>
          </div>

          {/* Search CTA */}
          <button 
            type="submit"
            className="w-full md:w-auto flex items-center justify-center gap-2 bg-gradient-to-r from-amber-400 via-amber-500 to-amber-600 text-[#030a1c] font-bold px-8 py-4 rounded-xl md:rounded-full hover:shadow-xl hover:shadow-amber-500/20 hover:scale-[1.02] active:scale-[0.98] transition-all duration-300 cursor-pointer shrink-0"
          >
            <Search className="w-5 h-5" />
            <span className="tracking-wider uppercase text-sm">Discover</span>
          </button>
        </motion.form>

        {/* Trust Indicators / Floating Badges */}
        <div className="mt-16 flex flex-wrap items-center justify-center gap-8 md:gap-16 text-slate-400 text-sm font-semibold tracking-widest uppercase">
          <div className="flex items-center gap-2 hover:text-white transition-colors">
            <ShieldCheck className="w-5 h-5 text-amber-400" />
            <span>Guaranteed Privacy</span>
          </div>
          <div className="flex items-center gap-2 hover:text-white transition-colors">
            <Compass className="w-5 h-5 text-amber-400" />
            <span>Elite Global Portfolio</span>
          </div>
          <div className="flex items-center gap-2 hover:text-white transition-colors">
            <Star className="w-5 h-5 text-amber-400 fill-amber-400" />
            <span>Bespoke Concierge</span>
          </div>
        </div>

      </div>

      {/* Elegant Bottom Border Overlay */}
      <div className="absolute bottom-0 left-0 right-0 h-24 bg-gradient-to-t from-[#020714] to-transparent pointer-events-none"></div>
    </div>
  );
}
