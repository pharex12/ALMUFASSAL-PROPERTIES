import React from 'react';
import { Building2, Mail, Phone, MapPin, Globe, Facebook, Instagram, Linkedin, ArrowUpRight } from 'lucide-react';

export default function Footer() {
  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert('Thank you for subscribing to our private ledger briefings.');
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#020714] border-t border-white/5 pt-20 pb-10 px-6 relative overflow-hidden">
      {/* Background elements */}
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-amber-500/5 blur-[120px] pointer-events-none"></div>

      <div className="max-w-7xl mx-auto relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          {/* Brand Column */}
          <div className="flex flex-col gap-6">
            <div className="flex items-center gap-3 cursor-pointer" onClick={scrollToTop}>
              <div className="relative flex items-center justify-center w-10 h-10 rounded-lg bg-gradient-to-br from-amber-400 to-amber-600 shadow-lg shadow-amber-500/20">
                <Building2 className="w-5 h-5 text-[#030a1c]" />
              </div>
              <div>
                <span className="text-lg font-bold tracking-[0.25em] text-white uppercase font-serif">
                  Almufassal
                </span>
                <span className="block text-[9px] tracking-[0.4em] text-amber-400 uppercase font-sans font-semibold -mt-1">
                  Properties
                </span>
              </div>
            </div>
            <p className="text-xs text-slate-400 font-light leading-relaxed">
              Curating exceptional residential legacies and high-yield real estate assets for sovereign funds, executives, and elite families globally.
            </p>
            {/* Social Links */}
            <div className="flex items-center gap-3">
              {[
                { icon: <Facebook className="w-4 h-4" />, href: '#' },
                { icon: <Instagram className="w-4 h-4" />, href: '#' },
                { icon: <Linkedin className="w-4 h-4" />, href: '#' },
                { icon: <Globe className="w-4 h-4" />, href: '#' },
              ].map((social, i) => (
                <a
                  key={i}
                  href={social.href}
                  className="w-8 h-8 rounded-full bg-slate-900/50 border border-white/5 hover:border-amber-500/30 text-slate-400 hover:text-white flex items-center justify-center transition-all duration-300"
                >
                  {social.icon}
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-xs font-bold text-white uppercase tracking-widest mb-6">Navigational Ledger</h4>
            <ul className="flex flex-col gap-3 text-xs text-slate-400">
              {['Home', 'Properties', 'Agents', 'Testimonials'].map((link) => (
                <li key={link}>
                  <button
                    onClick={() => {
                      const el = document.getElementById(link.toLowerCase());
                      if (el) el.scrollIntoView({ behavior: 'smooth' });
                    }}
                    className="hover:text-amber-400 transition-colors flex items-center gap-1 group"
                  >
                    <span>{link}</span>
                    <ArrowUpRight className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Private Offices */}
          <div>
            <h4 className="text-xs font-bold text-white uppercase tracking-widest mb-6">Private Offices</h4>
            <ul className="flex flex-col gap-4 text-xs text-slate-400 font-light">
              <li className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-amber-400 shrink-0" />
                <span>Level 82, Burj Khalifa, Downtown Dubai, UAE</span>
              </li>
              <li className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-amber-400 shrink-0" />
                <span>+971 4 000 0000</span>
              </li>
              <li className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-amber-400 shrink-0" />
                <span>concierge@almufassal.com</span>
              </li>
            </ul>
          </div>

          {/* Newsletter / Briefing */}
          <div>
            <h4 className="text-xs font-bold text-white uppercase tracking-widest mb-6">Private Ledger Briefing</h4>
            <p className="text-xs text-slate-400 font-light leading-relaxed mb-4">
              Receive off-market property listings and sovereign yield reports directly to your private inbox.
            </p>
            <form onSubmit={handleNewsletterSubmit} className="flex gap-2">
              <input
                type="email"
                required
                placeholder="Private Email Address"
                className="flex-1 px-4 py-2.5 bg-slate-900/40 border border-white/10 rounded-lg text-white text-xs focus:outline-none focus:border-amber-500 placeholder:text-slate-600"
              />
              <button
                type="submit"
                className="px-4 py-2.5 rounded-lg bg-gradient-to-r from-amber-400 to-amber-600 text-[#030a1c] font-bold text-xs uppercase tracking-wider hover:shadow-lg hover:shadow-amber-500/10 transition-all duration-300"
              >
                Subscribe
              </button>
            </form>
          </div>
        </div>

        <hr className="border-white/5 mb-8" />

        {/* Bottom copyright */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 text-[10px] text-slate-500 uppercase tracking-widest">
          <span>© {new Date().getFullYear()} Almufassal Properties. All Rights Reserved.</span>
          <div className="flex gap-6">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Engagement</a>
            <a href="#" className="hover:text-white transition-colors">Sovereign Compliance</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
