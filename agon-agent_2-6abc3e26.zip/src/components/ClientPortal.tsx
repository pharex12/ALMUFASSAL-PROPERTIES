import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, User, Shield, Heart, FileText, Calendar, Building, MessageSquare, Clock, ArrowRight } from 'lucide-react';
import supabase from '../lib/supabase';

interface ClientPortalProps {
  isOpen: boolean;
  onClose: () => void;
  user: any;
  savedProperties: any[];
  onUnsave: (id: number) => void;
  onInquire: (property: any) => void;
}

export default function ClientPortal({ isOpen, onClose, user, savedProperties, onUnsave, onInquire }: ClientPortalProps) {
  const [activeTab, setActiveTab] = useState<'saved' | 'inquiries'>('saved');
  const [inquiries, setInquiries] = useState<any[]>([]);
  const [loadingInquiries, setLoadingInquiries] = useState(false);

  useEffect(() => {
    if (user && isOpen && activeTab === 'inquiries') {
      fetchInquiries();
    }
  }, [user, isOpen, activeTab]);

  const fetchInquiries = async () => {
    setLoadingInquiries(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return;

      const res = await fetch('/api/inquiries', {
        headers: {
          'Authorization': `Bearer ${session.access_token}`
        }
      });
      if (res.ok) {
        const data = await res.json();
        setInquiries(data);
      }
    } catch (err) {
      console.error('Error fetching inquiries:', err);
    } finally {
      setLoadingInquiries(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status?.toLowerCase()) {
      case 'pending':
        return 'bg-amber-500/10 text-amber-400 border-amber-500/20';
      case 'contacted':
        return 'bg-green-500/10 text-green-400 border-green-500/20';
      default:
        return 'bg-slate-500/10 text-slate-400 border-slate-500/20';
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex justify-end">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-[#020714]/80 backdrop-blur-sm"
          ></motion.div>

          {/* Drawer container */}
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 180 }}
            className="relative w-full max-w-md h-full bg-[#030a1c] border-l border-white/10 shadow-2xl z-10 flex flex-col"
          >
            {/* Header */}
            <div className="p-6 border-b border-white/5 flex items-center justify-between bg-gradient-to-r from-amber-500/5 to-transparent">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-amber-500/10 border border-amber-500/20 flex items-center justify-center">
                  <User className="w-5 h-5 text-amber-400" />
                </div>
                <div>
                  <h3 className="text-lg font-serif font-bold text-white leading-tight">Client Portal</h3>
                  <p className="text-xs text-slate-400 font-light truncate max-w-[200px]">{user?.email}</p>
                </div>
              </div>
              <button 
                onClick={onClose}
                className="p-2 rounded-lg bg-slate-900/40 border border-white/5 text-slate-400 hover:text-white hover:border-amber-500/30 transition-all duration-300"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Tabs */}
            <div className="flex border-b border-white/5 bg-[#020714]/40 p-2">
              <button
                onClick={() => setActiveTab('saved')}
                className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider transition-all duration-300 ${
                  activeTab === 'saved'
                    ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Heart className="w-4 h-4" />
                <span>Saved Estates</span>
              </button>
              <button
                onClick={() => setActiveTab('inquiries')}
                className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider transition-all duration-300 ${
                  activeTab === 'inquiries'
                    ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <FileText className="w-4 h-4" />
                <span>My Inquiries</span>
              </button>
            </div>

            {/* Content Area */}
            <div className="flex-1 overflow-y-auto p-6">
              {activeTab === 'saved' ? (
                <div className="flex flex-col gap-4">
                  {savedProperties.length === 0 ? (
                    <div className="text-center py-16 flex flex-col items-center">
                      <Heart className="w-12 h-12 text-slate-600 mb-4" />
                      <h4 className="text-white font-medium mb-1">No Saved Properties</h4>
                      <p className="text-xs text-slate-400 max-w-[240px] mx-auto leading-relaxed">
                        Curate your private ledger of exceptional estates by saving them during exploration.
                      </p>
                    </div>
                  ) : (
                    savedProperties.map((saved) => {
                      const prop = saved.properties;
                      if (!prop) return null;
                      return (
                        <div key={saved.id} className="group bg-[#030a1c] border border-white/5 rounded-xl overflow-hidden hover:border-amber-500/20 transition-all duration-300 flex">
                          <img src={prop.image_url} alt={prop.title} className="w-24 h-24 object-cover" />
                          <div className="p-4 flex-1 flex flex-col justify-between min-w-0">
                            <div>
                              <h4 className="text-sm font-semibold text-white truncate group-hover:text-amber-400 transition-colors">{prop.title}</h4>
                              <p className="text-[10px] text-slate-400 truncate mb-1">{prop.location}</p>
                              <span className="text-xs font-serif font-bold text-amber-400">
                                {new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(prop.price)}
                              </span>
                            </div>
                            <div className="flex items-center justify-between mt-2">
                              <button
                                onClick={() => onInquire(prop)}
                                className="text-[10px] font-bold uppercase tracking-wider text-amber-400 hover:text-white transition-colors flex items-center gap-1"
                              >
                                <span>Inquire</span>
                                <ArrowRight className="w-3 h-3" />
                              </button>
                              <button
                                onClick={() => onUnsave(prop.id)}
                                className="text-[10px] text-slate-400 hover:text-red-400 transition-colors"
                              >
                                Remove
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              ) : (
                <div className="flex flex-col gap-4">
                  {loadingInquiries ? (
                    <div className="flex flex-col items-center justify-center py-12">
                      <div className="w-8 h-8 border-2 border-amber-500 border-t-transparent rounded-full animate-spin mb-3"></div>
                      <span className="text-xs text-slate-400">Retrieving private ledger...</span>
                    </div>
                  ) : inquiries.length === 0 ? (
                    <div className="text-center py-16 flex flex-col items-center">
                      <FileText className="w-12 h-12 text-slate-600 mb-4" />
                      <h4 className="text-white font-medium mb-1">No Active Inquiries</h4>
                      <p className="text-xs text-slate-400 max-w-[240px] mx-auto leading-relaxed">
                        Submit an inquiry on any residence to schedule a private viewing or speak with our concierge.
                      </p>
                    </div>
                  ) : (
                    inquiries.map((inq) => (
                      <div key={inq.id} className="bg-[#030a1c] border border-white/5 rounded-xl p-4 flex flex-col gap-3">
                        <div className="flex items-start justify-between gap-4">
                          <div>
                            <span className={`inline-block px-2.5 py-0.5 rounded-full text-[9px] font-bold tracking-widest uppercase border ${getStatusColor(inq.status)}`}>
                              {inq.status}
                            </span>
                            <span className="text-[10px] text-slate-500 block mt-1 flex items-center gap-1">
                              <Clock className="w-3 h-3" />
                              {new Date(inq.created_at).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}
                            </span>
                          </div>
                          <div className="text-right">
                            <span className="text-[10px] text-slate-400 uppercase tracking-widest block">Reference</span>
                            <span className="text-xs font-semibold text-white">#ALM-{inq.id}</span>
                          </div>
                        </div>

                        {inq.properties ? (
                          <div className="flex items-center gap-3 p-2 bg-slate-900/40 rounded-lg border border-white/5">
                            <img src={inq.properties.image_url} alt={inq.properties.title} className="w-10 h-10 object-cover rounded" />
                            <div className="min-w-0">
                              <h5 className="text-xs font-semibold text-white truncate">{inq.properties.title}</h5>
                              <p className="text-[10px] text-slate-400 truncate">{inq.properties.location}</p>
                            </div>
                          </div>
                        ) : (
                          <div className="p-2 bg-slate-900/40 rounded-lg border border-white/5">
                            <h5 className="text-xs font-semibold text-white">General Portfolio Inquiry</h5>
                          </div>
                        )}

                        <p className="text-xs text-slate-300 font-light leading-relaxed bg-[#020714]/40 p-2.5 rounded-lg border border-white/5 italic">
                          "{inq.message}"
                        </p>
                      </div>
                    ))
                  )}
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="p-6 border-t border-white/5 bg-[#020714]/60 text-center">
              <span className="text-[10px] text-slate-500 uppercase tracking-widest block mb-2">Private Support Concierge</span>
              <div className="flex justify-center gap-4 text-xs font-semibold text-amber-400">
                <a href="tel:+9714000000" className="hover:text-white transition-colors">Call: +971 4 000 0000</a>
                <span className="text-slate-700">|</span>
                <a href="mailto:concierge@almufassal.com" className="hover:text-white transition-colors">concierge@almufassal.com</a>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
