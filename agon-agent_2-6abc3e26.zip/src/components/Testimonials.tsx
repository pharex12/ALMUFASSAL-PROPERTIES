import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Quote, Star, ChevronLeft, ChevronRight } from 'lucide-react';

interface Testimonial {
  id: number;
  name: string;
  role: string;
  quote: string;
  rating: number;
  image_url: string;
}

export default function Testimonials() {
  const [testimonials, setTestimonials] = useState<Testimonial[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const fetchTestimonials = async () => {
      try {
        const res = await fetch('/api/testimonials');
        if (res.ok) {
          const data = await res.json();
          setTestimonials(data);
        }
      } catch (err) {
        console.error('Error fetching testimonials:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchTestimonials();
  }, []);

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev === 0 ? testimonials.length - 1 : prev - 1));
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev === testimonials.length - 1 ? 0 : prev + 1));
  };

  return (
    <section className="relative py-24 bg-[#020714] border-t border-white/5 overflow-hidden" id="testimonials">
      {/* Background blur */}
      <div className="absolute top-1/2 right-0 w-96 h-96 bg-blue-500/5 blur-[120px] pointer-events-none"></div>

      <div className="max-w-5xl mx-auto px-6 relative z-10">
        
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="text-amber-400 text-xs font-bold tracking-[0.25em] uppercase block mb-3">
            Client Ledger
          </span>
          <h2 className="text-3xl md:text-5xl font-serif font-bold text-white tracking-tight">
            Legacies of Trust
          </h2>
        </div>

        {loading ? (
          <div className="h-64 bg-[#030a1c]/40 border border-white/5 rounded-3xl animate-pulse"></div>
        ) : testimonials.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-slate-400">Ledger entries are currently private.</p>
          </div>
        ) : (
          <div className="relative">
            {/* Main Testimonial Card */}
            <motion.div
              key={currentIndex}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.5 }}
              className="bg-[#030a1c]/40 backdrop-blur-md border border-white/5 rounded-3xl p-8 md:p-12 md:flex items-center gap-8 shadow-2xl shadow-black/40"
            >
              {/* Client Image */}
              <div className="w-24 h-24 md:w-32 md:h-32 rounded-full overflow-hidden border-2 border-amber-500/30 shrink-0 mb-6 md:mb-0 mx-auto md:mx-0">
                <img 
                  src={testimonials[currentIndex].image_url} 
                  alt={testimonials[currentIndex].name}
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Quote details */}
              <div className="flex-1 text-center md:text-left">
                <Quote className="w-10 h-10 text-amber-500/20 mb-4 mx-auto md:mx-0" />
                
                {/* Rating */}
                <div className="flex items-center justify-center md:justify-start gap-1 mb-4">
                  {[...Array(testimonials[currentIndex].rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                  ))}
                </div>

                {/* Quote */}
                <p className="text-lg md:text-xl text-slate-200 font-light italic leading-relaxed mb-6">
                  "{testimonials[currentIndex].quote}"
                </p>

                {/* Author */}
                <div>
                  <h4 className="text-base font-serif font-bold text-white mb-0.5">
                    {testimonials[currentIndex].name}
                  </h4>
                  <p className="text-xs text-amber-400 font-semibold tracking-wider uppercase">
                    {testimonials[currentIndex].role}
                  </p>
                </div>
              </div>
            </motion.div>

            {/* Slider Controls */}
            <div className="flex justify-center md:justify-end gap-3 mt-8">
              <button
                onClick={handlePrev}
                className="w-11 h-11 rounded-full bg-slate-900/50 border border-white/10 hover:border-amber-500/30 text-slate-400 hover:text-white flex items-center justify-center transition-all duration-300"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              <button
                onClick={handleNext}
                className="w-11 h-11 rounded-full bg-slate-900/50 border border-white/10 hover:border-amber-500/30 text-slate-400 hover:text-white flex items-center justify-center transition-all duration-300"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
