import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Send, Phone, Mail, User, CheckCircle } from 'lucide-react';

interface Property {
  id: number;
  title: string;
  location: string;
  image_url: string;
}

interface InquiryModalProps {
  property: Property | null;
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: { property_id: number | null; name: string; email: string; phone: string; message: string }) => Promise<boolean>;
}

export default function InquiryModal({ property, isOpen, onClose, onSubmit }: InquiryModalProps) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [message, setMessage] = useState(
    property 
      ? `Dear Almufassal Concierge,\n\nI am highly interested in the exquisite property: "${property.title}" located in ${property.location}. Please provide additional private details and schedule a bespoke viewing.`
      : 'Dear Almufassal Concierge,\n\nI would love to explore your private portfolio of ultra-luxury estates. Please contact me at your earliest convenience.'
  );
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    const ok = await onSubmit({
      property_id: property ? property.id : null,
      name,
      email,
      phone,
      message
    });
    setSubmitting(false);
    if (ok) {
      setSuccess(true);
      setTimeout(() => {
        setSuccess(false);
        onClose();
        setName('');
        setEmail('');
        setPhone('');
      }, 3000);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-[#020714]/90 backdrop-blur-md"
          ></motion.div>

          {/* Modal Container */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="relative w-full max-w-xl bg-[#030a1c] border border-white/10 rounded-3xl overflow-hidden shadow-2xl shadow-black z-10"
          >
            {/* Header banner */}
            <div className="relative bg-gradient-to-r from-amber-400/20 via-amber-500/10 to-transparent p-6 border-b border-white/5">
              <button 
                onClick={onClose}
                className="absolute top-6 right-6 text-slate-400 hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
              <span className="text-amber-400 text-xs font-bold tracking-widest uppercase block mb-1">
                Private Inquiries
              </span>
              <h3 className="text-2xl font-serif font-bold text-white tracking-tight">
                {property ? 'Inquire About Estate' : 'Bespoke Portfolio Inquiry'}
              </h3>
            </div>

            {/* Success state */}
            {success ? (
              <div className="p-12 text-center flex flex-col items-center justify-center">
                <div className="w-16 h-16 rounded-full bg-amber-500/10 border border-amber-500/30 flex items-center justify-center mb-6 animate-bounce">
                  <CheckCircle className="w-8 h-8 text-amber-400" />
                </div>
                <h4 className="text-2xl font-serif font-bold text-white mb-2">Inquiry Submitted</h4>
                <p className="text-sm text-slate-400 font-light max-w-sm mx-auto">
                  Your private request has been registered. An Almufassal elite relationship agent will reach out within the hour.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="p-8 flex flex-col gap-5">
                
                {/* Property mini card if exists */}
                {property && (
                  <div className="flex items-center gap-4 p-3 bg-slate-900/50 border border-white/5 rounded-xl">
                    <img src={property.image_url} alt={property.title} className="w-14 h-14 object-cover rounded-lg" />
                    <div>
                      <h4 className="text-sm font-semibold text-white line-clamp-1">{property.title}</h4>
                      <p className="text-[11px] text-slate-400">{property.location}</p>
                    </div>
                  </div>
                )}

                {/* Name */}
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] text-slate-400 uppercase tracking-widest font-semibold">Full Name</label>
                  <div className="relative">
                    <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-amber-500/60" />
                    <input
                      type="text"
                      required
                      placeholder="e.g. Sir Richard Sterling"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full pl-11 pr-4 py-3 bg-slate-900/40 border border-white/10 rounded-xl text-white text-sm focus:outline-none focus:border-amber-500 transition-colors placeholder:text-slate-600"
                    />
                  </div>
                </div>

                {/* Email & Phone */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="flex flex-col gap-1.5">
                    <label className="text-[10px] text-slate-400 uppercase tracking-widest font-semibold">Private Email</label>
                    <div className="relative">
                      <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-amber-500/60" />
                      <input
                        type="email"
                        required
                        placeholder="richard@sterling.com"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full pl-11 pr-4 py-3 bg-slate-900/40 border border-white/10 rounded-xl text-white text-sm focus:outline-none focus:border-amber-500 transition-colors placeholder:text-slate-600"
                      />
                    </div>
                  </div>
                  <div className="flex flex-col gap-1.5">
                    <label className="text-[10px] text-slate-400 uppercase tracking-widest font-semibold">Direct Phone</label>
                    <div className="relative">
                      <Phone className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-amber-500/60" />
                      <input
                        type="tel"
                        placeholder="+971 50 123 4567"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        className="w-full pl-11 pr-4 py-3 bg-slate-900/40 border border-white/10 rounded-xl text-white text-sm focus:outline-none focus:border-amber-500 transition-colors placeholder:text-slate-600"
                      />
                    </div>
                  </div>
                </div>

                {/* Message */}
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] text-slate-400 uppercase tracking-widest font-semibold">Bespoke Requirements</label>
                  <textarea
                    required
                    rows={4}
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    className="w-full px-4 py-3 bg-slate-900/40 border border-white/10 rounded-xl text-white text-sm focus:outline-none focus:border-amber-500 transition-colors placeholder:text-slate-600 resize-none leading-relaxed"
                  />
                </div>

                {/* Submit */}
                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full py-4 mt-2 rounded-xl bg-gradient-to-r from-amber-400 via-amber-500 to-amber-600 text-[#030a1c] font-bold text-sm tracking-wider uppercase hover:shadow-xl hover:shadow-amber-500/15 transition-all duration-300 flex items-center justify-center gap-2"
                >
                  {submitting ? (
                    <div className="w-5 h-5 border-2 border-[#030a1c] border-t-transparent rounded-full animate-spin"></div>
                  ) : (
                    <>
                      <Send className="w-4 h-4" />
                      <span>Transmit Private Inquiry</span>
                    </>
                  )}
                </button>
              </form>
            )}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
