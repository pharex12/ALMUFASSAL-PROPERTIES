import React, { useState, useEffect } from 'react';
import { Building2, User, LogOut, Menu, X, Heart, MessageSquare } from 'lucide-react';
import supabase from '../lib/supabase';
import { signInWithGoogle } from '../lib/googleAuth';

interface NavbarProps {
  onOpenPortal: () => void;
  onOpenAuth: () => void;
  user: any;
  savedCount: number;
}

export default function Navbar({ onOpenPortal, onOpenAuth, user, savedCount }: NavbarProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleSignOut = async () => {
    await supabase.auth.signOut();
  };

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
      setIsMobileMenuOpen(false);
    }
  };

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
      isScrolled 
        ? 'bg-[#030a1c]/85 backdrop-blur-md border-b border-amber-500/20 py-4 shadow-xl shadow-black/30' 
        : 'bg-transparent py-6'
    }`}>
      <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
        {/* Logo */}
        <div className="flex items-center gap-3 cursor-pointer group" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
          <div className="relative flex items-center justify-center w-10 h-10 rounded-lg bg-gradient-to-br from-amber-400 to-amber-600 shadow-lg shadow-amber-500/20 transition-transform group-hover:scale-105 duration-300">
            <Building2 className="w-5 h-5 text-[#030a1c]" />
            <div className="absolute inset-0 rounded-lg border border-white/20 animate-pulse"></div>
          </div>
          <div>
            <span className="text-lg font-bold tracking-[0.25em] text-white uppercase font-serif">
              Almufassal
            </span>
            <span className="block text-[9px] tracking-[0.4em] text-amber-400 uppercase font-sans font-semibold -mt-1">
              Properties
            </span>
          </div>
        </div>

        {/* Desktop Nav Links */}
        <div className="hidden md:flex items-center gap-8">
          {['Home', 'Properties', 'Agents', 'Testimonials'].map((section) => (
            <button
              key={section}
              onClick={() => scrollToSection(section.toLowerCase())}
              className="text-sm font-medium tracking-wider text-slate-300 hover:text-amber-400 transition-colors duration-300 relative py-1 group"
            >
              {section}
              <span className="absolute bottom-0 left-0 w-0 h-[2px] bg-gradient-to-r from-amber-400 to-amber-600 transition-all duration-300 group-hover:w-full"></span>
            </button>
          ))}
        </div>

        {/* Desktop Action Buttons */}
        <div className="hidden md:flex items-center gap-4">
          {user ? (
            <div className="flex items-center gap-3">
              <button
                onClick={onOpenPortal}
                className="flex items-center gap-2 px-4 py-2 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 hover:bg-amber-500/20 transition-all duration-300 text-sm font-semibold tracking-wider shadow-lg shadow-amber-500/5 relative"
              >
                <User className="w-4 h-4" />
                <span>Portal</span>
                {savedCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-amber-500 text-[#030a1c] text-xs font-bold w-5 h-5 rounded-full flex items-center justify-center animate-bounce">
                    {savedCount}
                  </span>
                )}
              </button>
              <button
                onClick={handleSignOut}
                className="flex items-center justify-center w-10 h-10 rounded-full bg-slate-800/50 border border-slate-700 hover:border-red-500/40 hover:bg-red-500/10 text-slate-400 hover:text-red-400 transition-all duration-300"
                title="Sign Out"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <button
              onClick={onOpenAuth}
              className="px-6 py-2.5 rounded-full bg-gradient-to-r from-amber-400 via-amber-500 to-amber-600 text-[#030a1c] font-bold text-sm tracking-wider hover:shadow-lg hover:shadow-amber-500/20 hover:scale-[1.03] transition-all duration-300"
            >
              Client Portal
            </button>
          )}
        </div>

        {/* Mobile menu button */}
        <div className="md:hidden flex items-center gap-3">
          {user && (
            <button
              onClick={onOpenPortal}
              className="relative p-2 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-400"
            >
              <User className="w-5 h-5" />
              {savedCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-amber-500 text-[#030a1c] text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                  {savedCount}
                </span>
              )}
            </button>
          )}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="p-2 rounded-lg bg-slate-800/50 border border-slate-700 text-white hover:border-amber-500/40 transition-colors"
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden absolute top-full left-0 right-0 bg-[#030a1c]/95 backdrop-blur-lg border-b border-amber-500/20 py-6 px-6 flex flex-col gap-4 animate-fadeIn">
          {['Home', 'Properties', 'Agents', 'Testimonials'].map((section) => (
            <button
              key={section}
              onClick={() => scrollToSection(section.toLowerCase())}
              className="text-left py-2 text-slate-300 hover:text-amber-400 transition-colors tracking-widest font-medium"
            >
              {section}
            </button>
          ))}
          <hr className="border-slate-800" />
          {user ? (
            <div className="flex flex-col gap-3">
              <button
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  onOpenPortal();
                }}
                className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400 font-semibold"
              >
                <User className="w-4 h-4" />
                <span>My Client Portal</span>
              </button>
              <button
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  handleSignOut();
                }}
                className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400 font-semibold"
              >
                <LogOut className="w-4 h-4" />
                <span>Sign Out</span>
              </button>
            </div>
          ) : (
            <button
              onClick={() => {
                setIsMobileMenuOpen(false);
                onOpenAuth();
              }}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-400 to-amber-600 text-[#030a1c] font-bold text-center tracking-widest"
            >
              Access Client Portal
            </button>
          )}
        </div>
      )}
    </nav>
  );
}
