import React from 'react';
import { motion } from 'framer-motion';
import { Award, Landmark, TrendingUp, Users } from 'lucide-react';

export default function Stats() {
  const stats = [
    {
      icon: <Landmark className="w-6 h-6 text-amber-400" />,
      value: "$4.2B+",
      label: "Total Transactions",
      desc: "Securing generational wealth"
    },
    {
      icon: <TrendingUp className="w-6 h-6 text-amber-400" />,
      value: "18.4%",
      label: "Average Annual ROI",
      desc: "Outperforming premium indices"
    },
    {
      icon: <Users className="w-6 h-6 text-amber-400" />,
      value: "1,200+",
      label: "VVIP Global Clients",
      desc: "Sovereigns, executives & icons"
    },
    {
      icon: <Award className="w-6 h-6 text-amber-400" />,
      value: "25+",
      label: "Design Laurels",
      desc: "For architectural masterpiece curation"
    }
  ];

  return (
    <section className="relative py-24 bg-[#020714] overflow-hidden">
      {/* Background elements */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-7xl h-px bg-gradient-to-r from-transparent via-amber-500/20 to-transparent"></div>
      
      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="relative group bg-[#030a1c]/40 backdrop-blur-md border border-white/5 rounded-2xl p-8 hover:border-amber-500/20 hover:bg-[#030a1c]/60 transition-all duration-500 hover:-translate-y-1"
            >
              {/* Gold Accent Line */}
              <div className="absolute top-0 left-0 w-full h-[2px] bg-gradient-to-r from-transparent via-amber-400 to-transparent scale-x-0 group-hover:scale-x-100 transition-transform duration-500"></div>

              {/* Icon Container */}
              <div className="w-12 h-12 rounded-xl bg-amber-400/5 border border-amber-400/10 flex items-center justify-center mb-6 group-hover:bg-amber-400/10 group-hover:border-amber-400/30 transition-all duration-300">
                {stat.icon}
              </div>

              {/* Value */}
              <h3 className="text-4xl font-serif font-bold text-white mb-2 tracking-tight group-hover:text-amber-300 transition-colors">
                {stat.value}
              </h3>

              {/* Label */}
              <h4 className="text-sm font-semibold text-amber-400 tracking-wider uppercase mb-1">
                {stat.label}
              </h4>

              {/* Description */}
              <p className="text-xs text-slate-400 font-light leading-relaxed">
                {stat.desc}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
