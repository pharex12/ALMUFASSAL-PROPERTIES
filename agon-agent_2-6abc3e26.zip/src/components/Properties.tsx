import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { BedDouble, Bath, Maximize, MapPin, Heart, Share2, Star, ChevronRight, Compass } from 'lucide-react';

interface Property {
  id: number;
  title: string;
  description: string;
  price: number;
  location: string;
  beds: number;
  baths: number;
  sqft: number;
  image_url: string;
  category: string;
  rating: number;
  features: string[];
}

interface PropertiesProps {
  properties: Property[];
  loading: boolean;
  savedIds: number[];
  onToggleSave: (id: number) => void;
  onInquire: (property: Property) => void;
}

export default function Properties({ properties, loading, savedIds, onToggleSave, onInquire }: PropertiesProps) {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedProperty, setSelectedProperty] = useState<Property | null>(null);

  const categories = ['All', 'Penthouse', 'Waterfront Villa', 'Private Mansion'];

  const filteredProperties = selectedCategory === 'All'
    ? properties
    : properties.filter(p => p.category === selectedCategory);

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      maximumFractionDigits: 0,
    }).format(price);
  };

  return (
    <section className="relative py-24 bg-[#020714] border-t border-white/5" id="properties">
      {/* Background details */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/5 blur-[120px] pointer-events-none"></div>
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-blue-500/5 blur-[120px] pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div>
            <span className="text-amber-400 text-xs font-bold tracking-[0.25em] uppercase block mb-3">
              Elite Collection
            </span>
            <h2 className="text-3xl md:text-5xl font-serif font-bold text-white tracking-tight leading-tight">
              Signature Residences
            </h2>
          </div>

          {/* Category Tabs */}
          <div className="flex flex-wrap gap-2">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-5 py-2.5 rounded-full text-xs font-semibold tracking-wider uppercase transition-all duration-300 border ${
                  selectedCategory === cat
                    ? 'bg-gradient-to-r from-amber-400 to-amber-600 text-[#030a1c] border-amber-500 shadow-lg shadow-amber-500/10'
                    : 'bg-slate-900/40 text-slate-300 border-white/10 hover:border-amber-500/30'
                }`}
              >
                {cat}s
              </button>
            ))}
          </div>
        </div>

        {/* Properties Grid */}
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[1, 2, 3].map((n) => (
              <div key={n} className="bg-[#030a1c]/40 rounded-2xl border border-white/5 h-[500px] animate-pulse"></div>
            ))}
          </div>
        ) : filteredProperties.length === 0 ? (
          <div className="text-center py-20 bg-[#030a1c]/20 border border-white/5 rounded-2xl">
            <p className="text-slate-400 text-lg">No premium estates match your filter options.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredProperties.map((property) => {
              const isSaved = savedIds.includes(property.id);
              return (
                <motion.div
                  key={property.id}
                  layout
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.5 }}
                  className="group bg-[#030a1c]/40 backdrop-blur-md border border-white/5 rounded-2xl overflow-hidden hover:border-amber-500/20 transition-all duration-500 flex flex-col h-full hover:shadow-2xl hover:shadow-black/60"
                >
                  {/* Image Container with Badge */}
                  <div className="relative aspect-[4/3] overflow-hidden">
                    <img 
                      src={property.image_url} 
                      alt={property.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#020714]/80 via-transparent to-transparent"></div>
                    
                    {/* Floating Badges */}
                    <div className="absolute top-4 left-4 flex gap-2">
                      <span className="px-3 py-1.5 rounded-md bg-[#030a1c]/80 backdrop-blur-md border border-amber-500/30 text-amber-400 text-[10px] font-bold tracking-widest uppercase">
                        {property.category}
                      </span>
                    </div>

                    {/* Save / Share Controls */}
                    <div className="absolute top-4 right-4 flex gap-2">
                      <button 
                        onClick={() => onToggleSave(property.id)}
                        className={`w-9 h-9 rounded-full flex items-center justify-center backdrop-blur-md border transition-all duration-300 ${
                          isSaved 
                            ? 'bg-amber-500 border-amber-600 text-[#030a1c]' 
                            : 'bg-[#030a1c]/60 border-white/10 text-white hover:text-amber-400 hover:border-amber-500/30'
                        }`}
                      >
                        <Heart className={`w-4 h-4 ${isSaved ? 'fill-[#030a1c]' : ''}`} />
                      </button>
                    </div>

                    {/* Price Tag Overlay */}
                    <div className="absolute bottom-4 left-4">
                      <span className="text-2xl font-serif font-bold text-white tracking-tight">
                        {formatPrice(property.price)}
                      </span>
                    </div>
                  </div>

                  {/* Content */}
                  <div className="p-6 flex-1 flex flex-col justify-between">
                    <div>
                      {/* Rating & Location */}
                      <div className="flex items-center justify-between mb-3 text-xs text-slate-400 font-medium">
                        <div className="flex items-center gap-1">
                          <MapPin className="w-3.5 h-3.5 text-amber-400" />
                          <span>{property.location}</span>
                        </div>
                        <div className="flex items-center gap-1 text-amber-400">
                          <Star className="w-3.5 h-3.5 fill-amber-400" />
                          <span>{property.rating.toFixed(1)}</span>
                        </div>
                      </div>

                      {/* Title */}
                      <h3 className="text-xl font-serif font-bold text-white mb-2 group-hover:text-amber-400 transition-colors line-clamp-1">
                        {property.title}
                      </h3>

                      {/* Description */}
                      <p className="text-xs text-slate-400 font-light leading-relaxed mb-6 line-clamp-2">
                        {property.description}
                      </p>
                    </div>

                    {/* Technical Specs & Action */}
                    <div>
                      <div className="grid grid-cols-3 gap-2 py-4 border-y border-white/5 mb-6 text-slate-300">
                        <div className="flex flex-col items-center">
                          <span className="text-[10px] text-slate-400 uppercase tracking-widest font-semibold mb-1">Beds</span>
                          <div className="flex items-center gap-1.5 font-medium">
                            <BedDouble className="w-4 h-4 text-amber-400" />
                            <span>{property.beds}</span>
                          </div>
                        </div>
                        <div className="flex flex-col items-center border-x border-white/5">
                          <span className="text-[10px] text-slate-400 uppercase tracking-widest font-semibold mb-1">Baths</span>
                          <div className="flex items-center gap-1.5 font-medium">
                            <Bath className="w-4 h-4 text-amber-400" />
                            <span>{property.baths}</span>
                          </div>
                        </div>
                        <div className="flex flex-col items-center">
                          <span className="text-[10px] text-slate-400 uppercase tracking-widest font-semibold mb-1">Sq Ft</span>
                          <div className="flex items-center gap-1.5 font-medium">
                            <Maximize className="w-4 h-4 text-amber-400" />
                            <span>{property.sqft.toLocaleString()}</span>
                          </div>
                        </div>
                      </div>

                      {/* Primary Action Buttons */}
                      <div className="grid grid-cols-2 gap-3">
                        <button
                          onClick={() => setSelectedProperty(property)}
                          className="py-2.5 rounded-lg border border-white/10 hover:border-amber-500/30 text-slate-300 hover:text-white text-xs font-semibold tracking-wider uppercase transition-colors"
                        >
                          View Details
                        </button>
                        <button
                          onClick={() => onInquire(property)}
                          className="py-2.5 rounded-lg bg-gradient-to-r from-amber-400 to-amber-600 text-[#030a1c] text-xs font-bold tracking-wider uppercase hover:shadow-lg hover:shadow-amber-500/10 transition-all duration-300"
                        >
                          Inquire
                        </button>
                      </div>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>

      {/* Property Details Modal / Drawer */}
      <AnimatePresence>
        {selectedProperty && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedProperty(null)}
              className="absolute inset-0 bg-[#020714]/90 backdrop-blur-md"
            ></motion.div>

            {/* Modal Box */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-4xl bg-[#030a1c] border border-white/10 rounded-3xl overflow-hidden shadow-2xl shadow-black z-10 grid grid-cols-1 md:grid-cols-2 max-h-[90vh] overflow-y-auto"
            >
              {/* Left Side: Media */}
              <div className="relative h-64 md:h-full min-h-[300px]">
                <img 
                  src={selectedProperty.image_url} 
                  alt={selectedProperty.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#030a1c] via-transparent to-transparent"></div>
                <div className="absolute top-6 left-6">
                  <span className="px-4 py-2 rounded-md bg-[#030a1c]/80 backdrop-blur-md border border-amber-500/30 text-amber-400 text-xs font-bold tracking-widest uppercase">
                    {selectedProperty.category}
                  </span>
                </div>
              </div>

              {/* Right Side: Details */}
              <div className="p-8 md:p-10 flex flex-col justify-between">
                <div>
                  {/* Close Button */}
                  <button 
                    onClick={() => setSelectedProperty(null)}
                    className="absolute top-6 right-6 text-slate-400 hover:text-white transition-colors"
                  >
                    <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </button>

                  <span className="text-amber-400 text-xs font-semibold tracking-widest uppercase mb-2 block flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5" />
                    {selectedProperty.location}
                  </span>

                  <h3 className="text-3xl font-serif font-bold text-white mb-4 pr-8">
                    {selectedProperty.title}
                  </h3>

                  <div className="text-2xl font-serif font-bold text-amber-400 mb-6">
                    {formatPrice(selectedProperty.price)}
                  </div>

                  <p className="text-sm text-slate-300 font-light leading-relaxed mb-6">
                    {selectedProperty.description}
                  </p>

                  {/* Specs Grid */}
                  <div className="grid grid-cols-3 gap-4 py-4 border-y border-white/5 mb-6 text-slate-300">
                    <div>
                      <span className="text-[10px] text-slate-400 uppercase tracking-widest font-semibold mb-1 block">Beds</span>
                      <span className="text-lg font-medium">{selectedProperty.beds} Bedrooms</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 uppercase tracking-widest font-semibold mb-1 block">Baths</span>
                      <span className="text-lg font-medium">{selectedProperty.baths} Bathrooms</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 uppercase tracking-widest font-semibold mb-1 block">Area</span>
                      <span className="text-lg font-medium">{selectedProperty.sqft.toLocaleString()} Sq Ft</span>
                    </div>
                  </div>

                  {/* Features */}
                  <div className="mb-8">
                    <h4 className="text-xs font-bold text-white uppercase tracking-widest mb-3">Premium Inclusions</h4>
                    <div className="flex flex-wrap gap-2">
                      {selectedProperty.features?.map((feature, i) => (
                        <span key={i} className="px-3 py-1.5 rounded-md bg-slate-800/30 border border-white/5 text-slate-300 text-xs font-medium">
                          {feature}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {/* CTA */}
                <div className="flex gap-4">
                  <button
                    onClick={() => {
                      onInquire(selectedProperty);
                      setSelectedProperty(null);
                    }}
                    className="flex-1 py-4 rounded-xl bg-gradient-to-r from-amber-400 to-amber-600 text-[#030a1c] font-bold text-sm tracking-wider uppercase hover:shadow-xl hover:shadow-amber-500/10 transition-all duration-300 flex items-center justify-center gap-2"
                  >
                    <span>Initiate Private Inquiry</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
}
