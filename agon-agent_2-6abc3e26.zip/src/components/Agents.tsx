import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Mail, Phone, MapPin, Award, ShieldCheck, Heart } from 'lucide-react';

interface Agent {
  id: number;
  name: string;
  role: string;
  email: string;
  phone: string;
  image_url: string;
  rating: number;
}

export default function Agents() {
  const [agents, setAgents] = useState<Agent[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAgents = async () => {
      try {
        const res = await fetch('/api/agents');
        if (res.ok) {
          const data = await res.json();
          setAgents(data);
        }
      } catch (err) {
        console.error('Error fetching agents:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchAgents();
  }, []);

  return (
    <section className="relative py-24 bg-[#020714]" id="agents">
      {/* Background elements */}
      <div className="absolute top-1/2 left-0 w-80 h-80 bg-amber-500/5 blur-[120px] pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-amber-400 text-xs font-bold tracking-[0.25em] uppercase block mb-3">
            Elite Advisory
          </span>
          <h2 className="text-3xl md:text-5xl font-serif font-bold text-white tracking-tight mb-4">
            Private Portfolio Partners
          </h2>
          <p className="text-sm text-slate-400 font-light leading-relaxed">
            Our elite advisors possess unparalleled expertise in securing generational estates and negotiating bespoke waterfront portfolios.
          </p>
        </div>

        {/* Agents Grid */}
        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {[1, 2, 3].map((n) => (
              <div key={n} className="bg-[#030a1c]/40 rounded-2xl border border-white/5 h-[400px] animate-pulse"></div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {agents.map((agent, index) => (
              <motion.div
                key={agent.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="group bg-[#030a1c]/40 backdrop-blur-md border border-white/5 rounded-2xl overflow-hidden hover:border-amber-500/20 transition-all duration-500 flex flex-col"
              >
                {/* Agent Image */}
                <div className="relative aspect-[3/4] overflow-hidden">
                  <img 
                    src={agent.image_url} 
                    alt={agent.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#020714] via-transparent to-transparent"></div>
                  
                  {/* Rating Badge */}
                  <div className="absolute top-4 left-4 flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-[#030a1c]/80 backdrop-blur-md border border-amber-500/20 text-amber-400 text-xs font-bold">
                    <Award className="w-4 h-4" />
                    <span>Elite Advisor</span>
                  </div>
                </div>

                {/* Agent Details */}
                <div className="p-6 text-center flex-1 flex flex-col justify-between">
                  <div>
                    <h3 className="text-xl font-serif font-bold text-white mb-1 group-hover:text-amber-400 transition-colors">
                      {agent.name}
                    </h3>
                    <p className="text-xs text-amber-400/80 font-semibold tracking-wider uppercase mb-4">
                      {agent.role}
                    </p>
                  </div>

                  {/* Contact Info */}
                  <div className="flex flex-col gap-2.5 py-4 border-t border-white/5 text-xs text-slate-300">
                    <a 
                      href={`mailto:${agent.email}`}
                      className="flex items-center justify-center gap-2 hover:text-amber-400 transition-colors"
                    >
                      <Mail className="w-4 h-4 text-amber-400" />
                      <span>{agent.email}</span>
                    </a>
                    <a 
                      href={`tel:${agent.phone}`}
                      className="flex items-center justify-center gap-2 hover:text-amber-400 transition-colors"
                    >
                      <Phone className="w-4 h-4 text-amber-400" />
                      <span>{agent.phone}</span>
                    </a>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
