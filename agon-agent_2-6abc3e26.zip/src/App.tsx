import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Stats from './components/Stats';
import Properties from './components/Properties';
import Agents from './components/Agents';
import Testimonials from './components/Testimonials';
import Footer from './components/Footer';
import AuthModal from './components/AuthModal';
import ClientPortal from './components/ClientPortal';
import InquiryModal from './components/InquiryModal';
import supabase from './lib/supabase';
import { handleGoogleRedirect } from './lib/googleAuth';

// Initialize Google Redirect handler once at startup
handleGoogleRedirect();

export default function App() {
  const [user, setUser] = useState<any>(null);
  const [properties, setProperties] = useState<any[]>([]);
  const [savedProperties, setSavedProperties] = useState<any[]>([]);
  const [loadingProperties, setLoadingProperties] = useState(true);
  
  // Modals state
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [isPortalOpen, setIsPortalOpen] = useState(false);
  const [isInquiryOpen, setIsInquiryOpen] = useState(false);
  const [selectedPropertyForInquiry, setSelectedPropertyForInquiry] = useState<any | null>(null);

  // Filter states (for API search query)
  const [filters, setFilters] = useState({
    category: 'All',
    location: 'All',
    minPrice: '',
    maxPrice: '',
  });

  // Listen to auth state
  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
    });

    return () => subscription.unsubscribe();
  }, []);

  // Fetch properties on mount or filter change
  useEffect(() => {
    fetchProperties();
  }, [filters]);

  // Fetch saved properties if user is logged in
  useEffect(() => {
    if (user) {
      fetchSavedProperties();
    } else {
      setSavedProperties([]);
    }
  }, [user]);

  const fetchProperties = async () => {
    setLoadingProperties(true);
    try {
      const params = new URLSearchParams();
      if (filters.category && filters.category !== 'All') params.append('category', filters.category);
      if (filters.location && filters.location !== 'All') params.append('location', filters.location);
      if (filters.minPrice) params.append('min_price', (parseFloat(filters.minPrice) * 1000000).toString());
      if (filters.maxPrice) params.append('max_price', (parseFloat(filters.maxPrice) * 1000000).toString());

      const res = await fetch(`/api/properties?${params.toString()}`);
      if (res.ok) {
        const data = await res.json();
        setProperties(data);
      }
    } catch (err) {
      console.error('Error fetching properties:', err);
    } finally {
      setLoadingProperties(false);
    }
  };

  const fetchSavedProperties = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return;

      const res = await fetch('/api/saved_properties', {
        headers: {
          'Authorization': `Bearer ${session.access_token}`
        }
      });
      if (res.ok) {
        const data = await res.json();
        setSavedProperties(data);
      }
    } catch (err) {
      console.error('Error fetching saved properties:', err);
    }
  };

  const handleToggleSave = async (propertyId: number) => {
    if (!user) {
      setIsAuthOpen(true);
      return;
    }

    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return;

    const isCurrentlySaved = savedProperties.some((p) => p.property_id === propertyId);

    try {
      const method = isCurrentlySaved ? 'DELETE' : 'POST';
      const res = await fetch('/api/saved_properties', {
        method,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session.access_token}`
        },
        body: JSON.stringify({ property_id: propertyId })
      });

      if (res.ok) {
        fetchSavedProperties();
      }
    } catch (err) {
      console.error('Error toggling save:', err);
    }
  };

  const handleInquirySubmit = async (inquiryData: any) => {
    try {
      const headers: HeadersInit = {
        'Content-Type': 'application/json'
      };

      // Add auth token if user is logged in
      const { data: { session } } = await supabase.auth.getSession();
      if (session) {
        headers['Authorization'] = `Bearer ${session.access_token}`;
      }

      const res = await fetch('/api/inquiries', {
        method: 'POST',
        headers,
        body: JSON.stringify(inquiryData)
      });

      return res.ok;
    } catch (err) {
      console.error('Inquiry submission failed:', err);
      return false;
    }
  };

  const handleOpenInquiry = (property: any) => {
    setSelectedPropertyForInquiry(property);
    setIsInquiryOpen(true);
  };

  const savedIds = savedProperties.map((p) => p.property_id);

  return (
    <div className="bg-[#020714] min-h-screen text-white font-sans selection:bg-amber-400 selection:text-[#030a1c]">
      {/* Top Glassmorphic Navigation */}
      <Navbar 
        onOpenPortal={() => setIsPortalOpen(true)}
        onOpenAuth={() => setIsAuthOpen(true)}
        user={user}
        savedCount={savedProperties.length}
      />

      {/* Parallax Hero Centerpiece */}
      <Hero 
        onSearch={(newFilters) => setFilters(newFilters)}
      />

      {/* Trust & Performance Indicators */}
      <Stats />

      {/* Luxury Real Estate Listings */}
      <Properties 
        properties={properties}
        loading={loadingProperties}
        savedIds={savedIds}
        onToggleSave={handleToggleSave}
        onInquire={handleOpenInquiry}
      />

      {/* Premium Private Advisors */}
      <Agents />

      {/* Bespoke Client Testimonials */}
      <Testimonials />

      {/* Polished Footer */}
      <Footer />

      {/* Modals & Portal Overlays */}
      <AuthModal 
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        onSuccess={() => fetchSavedProperties()}
      />

      <ClientPortal 
        isOpen={isPortalOpen}
        onClose={() => setIsPortalOpen(false)}
        user={user}
        savedProperties={savedProperties}
        onUnsave={handleToggleSave}
        onInquire={handleOpenInquiry}
      />

      <InquiryModal 
        property={selectedPropertyForInquiry}
        isOpen={isInquiryOpen}
        onClose={() => {
          setIsInquiryOpen(false);
          setSelectedPropertyForInquiry(null);
        }}
        onSubmit={handleInquirySubmit}
      />
    </div>
  );
}
