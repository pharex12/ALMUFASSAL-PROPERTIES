import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { category, location, min_price, max_price } = req.query;
      let query = supabase.from('properties').select('*');

      if (category && category !== 'All') {
        query = query.eq('category', category);
      }
      if (location && location !== 'All') {
        query = query.ilike('location', `%${location}%`);
      }
      if (min_price) {
        query = query.gte('price', parseFloat(min_price));
      }
      if (max_price) {
        query = query.lte('price', parseFloat(max_price));
      }

      const { data, error } = await query.order('id', { ascending: true });
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'POST') {
      const property = req.body;
      const { data, error } = await supabase
        .from('properties')
        .insert(property)
        .select()
        .single();
      if (error) throw error;
      return res.status(201).json(data);
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: err.message });
  }
}
