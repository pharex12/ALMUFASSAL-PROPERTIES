import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    // Optional Auth Verification
    let userId = null;
    const token = req.headers.authorization?.replace('Bearer ', '');
    if (token) {
      const { data: { user }, error: authError } = await supabase.auth.getUser(token);
      if (!authError && user) {
        userId = user.id;
      }
    }

    if (req.method === 'GET') {
      // If user is logged in, fetch their inquiries. Otherwise, return 401 unless it's a general request
      if (!userId) {
        return res.status(401).json({ error: 'Unauthorized. Please log in to view inquiries.' });
      }
      
      const { data, error } = await supabase
        .from('inquiries')
        .select('*, properties(*)')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });
        
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'POST') {
      const { property_id, name, email, phone, message } = req.body;
      if (!name || !email || !message) {
        return res.status(400).json({ error: 'Name, email, and message are required.' });
      }

      const inquiryData = {
        property_id: property_id ? parseInt(property_id) : null,
        user_id: userId, // associate with user if logged in
        name,
        email,
        phone,
        message,
        status: 'pending'
      };

      const { data, error } = await supabase
        .from('inquiries')
        .insert(inquiryData)
        .select()
        .single();

      if (error) throw error;
      return res.status(201).json(data);
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: err.message });
  }
}
