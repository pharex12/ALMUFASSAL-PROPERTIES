import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    const token = req.headers.authorization?.replace('Bearer ', '');
    if (!token) return res.status(401).json({ error: 'Unauthorized. Token missing.' });

    const { data: { user }, error: authError } = await supabase.auth.getUser(token);
    if (authError || !user) return res.status(401).json({ error: 'Unauthorized. Invalid token.' });

    if (req.method === 'GET') {
      const { data, error } = await supabase
        .from('saved_properties')
        .select('*, properties(*)')
        .eq('user_id', user.id);
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'POST') {
      const { property_id } = req.body;
      if (!property_id) return res.status(400).json({ error: 'Property ID required' });

      // Check if already saved
      const { data: existing } = await supabase
        .from('saved_properties')
        .select('id')
        .eq('user_id', user.id)
        .eq('property_id', parseInt(property_id))
        .maybeSingle();

      if (existing) {
        return res.status(200).json({ message: 'Property already saved', data: existing });
      }

      const { data, error } = await supabase
        .from('saved_properties')
        .insert({ user_id: user.id, property_id: parseInt(property_id) })
        .select()
        .single();

      if (error) throw error;
      return res.status(201).json(data);
    }

    if (req.method === 'DELETE') {
      const { property_id } = req.body;
      if (!property_id) return res.status(400).json({ error: 'Property ID required' });

      const { error } = await supabase
        .from('saved_properties')
        .delete()
        .eq('user_id', user.id)
        .eq('property_id', parseInt(property_id));

      if (error) throw error;
      return res.status(200).json({ ok: true, message: 'Property unsaved successfully.' });
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: err.message });
  }
}
